# Scaling Laws 机制与学习曲线

网站入口 `/notes/scaling_laws/`。六篇个人文献综述与研究笔记按机制组织，正文不展示代码、复现命令或练习。

1. statistical_geometry：统计估计、几何分辨率、宽度换算与数据/模型对偶。
2. spectral_learning：原联合谱模型、时间/数据/容量的完整推导。
3. discrete_structure：技能尾部、Poisson 计数、组合共享与数据选择。
4. feature_learning：时变度量、source 条件、动态加速与 SGD 暂态。
5. graph_language：2026 年 ER/BA 图与语言工作、熵率与计数基线。
6. compute_allocation：成本约束、经验曲面、损失底与协议敏感性。

## 图与计算

共十张自制计算图：五张由原神经网络理论系列迁移，五张为本专题新增。SVG 与 PNG 并存；绘图参数和诊断保存在 figures/ 与 numerical_checks.json。随机图使用独立生成的有限图，未进行 Transformer 训练；特征学习交叉图是有效时钟标度方程示意，不是完整 DMFT 复现。

新增图：安装 requirements.txt 后，在本目录运行 `python generate_figures.py`。
独立公式核查：`python review_checks.py`。覆盖时变度量、平滑计数交叉熵、Poisson 积分、几何偏差方差与计算最优条件。

原五图的基础计算位于相邻 neural_network_theory/：experiments.py 的历史编号 17–20 以及 extended_checks.py 的临界谱计算。历史实验编号稳定，experiments.json 的 topic、note_slug 和 figure 记录当前归属；输出将镜像至本专题 figures/。

## 文献与迁移

sources.json 记录十九篇原始文献及对应正文。注意预印本首发年与会议/期刊发表年不同；2025 年的特征学习模型初稿为 2024，Bahri 等的期刊版为 2024、初稿为 2021。

原 `/notes/neural_network_theory/scaling_laws/` 跳转本专题；time/data/model/compute 四个历史入口直接到对应章节。旧综合稿的六个主要节锚点由专题入口转发。原谱推导和五图全部保留，新增机制内容另行展开。

下载压缩包以 neural_network_theory/、scaling_laws/ 和 grokking/ 三个相邻目录保存材料，以维持跨专题计算镜像路径。三个专题下载链接提供相同的配套材料包。解压后可只阅读或运行需要的目录。

## 文字扩写记录

2026-10-22 六篇正文追加直观解释、公式衔接、模型比较和具体情境讨论，中文字符由 27678 增至 36902（增加约 33.3%）。公式序列、章节锚点、图与数值结果保持不变；分篇统计见 prose_expansion_report.json，expansion_report.json 保留此前专题迁移的历史统计。

## 2026-10-25 第一篇的 Teacher–Student 与论文公式

statistical_geometry 保留原前言与计算图，展开几何上界、带噪局部平滑、Gaussian 教师与学生、遗漏变量、随机特征的表示投影和有限数据核残差。Bahri 等式 (1)–(4) 的对应关系及平方损失的归一化差异记录在 sources.json，新增 Hastie 等的高维回归与模型失配文献；几何指数、理想模态截止和指定教师的目标对齐在正文中分别说明。

独立核对运行 `python notes/scaling_laws/statistical_geometry/checks.py`。checks.json 记录 12000 次有限 Gaussian 回归拟合、无噪声精确恢复、总体投影与教师平均、有限样本核残差的检查。测试风险用已知输入二阶矩直接计算，不引入有限测试集波动；这些核对不训练深层网络，也不宣称复现论文中的网络实验。扩写与网页验证记录见 statistical_geometry/revision_20261025.json。

## 2026-10-25 六篇结尾的边界与进展讨论

六篇结语各增加四个讨论小节，分别说明解释的适用条件、未解决的问题、选定文献的发展脉络和能够区分机制的实验方向。新增约 6610 个中文字符；各篇结语之前的正文、全部数学表达式、图和原有章节锚点保持不变。讨论包括噪声交叉、任务对齐、指标造成的表观涌现、浅层特征学习的风险与权重谱、随机图向语言推广的限制，以及推理计算对预算问题的扩展。

新增五篇原始文献，保留初稿与发表年份、修订版本及适用范围。2025 年初稿、2026 年修订的浅层网络谱研究，只用于讨论其分析的二次/对角网络及全局最优解，不当作一般深层网络的有限时间训练理论。扩写与页面验证见 discussion_revision_20261025.json；此前第一篇扩写和全系列扩写记录保留为历史阶段。

## 2026-10-25 前言补充与文字整理

六篇前言分别补充资源扫描、慢模态、技能共享、冻结特征比较、图任务损失底和预算搜索的具体动机。正文与结尾整理重复解释，删去与推导无关的收束句，将讨论标题改为具体内容。数学表达式序列、图、既有引用与显式锚点保持一致，未增加新的科学结论、文献或实验。

这轮文字整理在前两轮扩写之后进行，长度与验证单独记录在 editorial_revision_20261025.json；此前的扩写报告保留各自阶段的正文哈希与统计。
