# 配套材料

三个相邻目录 neural_network_theory/、scaling_laws/、grokking/ 保存个人笔记、原始文献索引、数值图与计算记录。请保持相邻位置，以便跨专题图像导出路径继续工作。每个目录 README.md 说明独立计算与来源。网页正文不包含代码或练习。
